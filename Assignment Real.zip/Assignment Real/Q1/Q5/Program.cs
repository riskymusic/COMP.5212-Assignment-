﻿using System;
using Question_4;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_5
{
    class Program
    {
        static void Main(string[] args)
        {
            driver d1 = new driver("James", "Taia", "Van", "BO12345");

            Console.WriteLine("Creating new Employee record...");
            Console.WriteLine("Adding Employee as args new Driver to drive Van...");

            Console.WriteLine("\nPlease enter license number for this employee: ");
            string licensenumber = Console.ReadLine();

            Console.WriteLine("\nThe following employee details have been Entered:\n");
            Console.WriteLine($"Drivers name: {d1.FirstName} {d1.LastName}");
            Console.WriteLine($"Drivers licence No: {licensenumber}");
            Console.WriteLine($"Vehicle: {d1.Vehicle}");
            Console.ReadLine();
        }
        class driver : Employee
        {
            public string Vehicle { get; set; }
            public string DriversLicenseNo { get; set; }

            

            public driver(string _firstname, string _lastname, string _vehicle, string _driverslicenseno):base(_firstname, _lastname)
            {
                
                Vehicle = _vehicle;
                DriversLicenseNo = _driverslicenseno;

            }


        }
    }
}
