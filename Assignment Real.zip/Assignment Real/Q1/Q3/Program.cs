﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_3
{
    class Program
    {
        static void Main(string[] args) //Main method
        {
            book a1 = new book("The book", "Roald Dahl", "New book Association");
            Console.WriteLine($"Title:{a1.Title}\nAuthor:{a1.Author}\nPublisher:{a1.Publisher}");
            Console.ReadLine();


        }
        class book
        {

            public string Title { get; set; } //Auto implemented properties
            public string Author { get; set; }
            public string Publisher { get; set; }




            public book() //constructor 
            { }
            public book(string _title, string _author, string _publisher) //Constructor 
            {
                Title = _title;
                Author = _author;
                Publisher = _publisher;
            }
        }
    }
}
