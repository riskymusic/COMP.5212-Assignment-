﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee e1 = new Employee("Jack", "Smith");


            string key;




            do
            {


                Console.WriteLine("\nEnter Details of new employee below: ");
                Console.Write("\nFirst name: ");
                string firstname = Console.ReadLine();
                Console.Write("Last name: ");
                string lastname = Console.ReadLine();
                Console.WriteLine("Creating new Employee record....");

                Console.WriteLine($"Year employee started working for the company: ");
                int yearstarted = int.Parse(Console.ReadLine());

                Console.WriteLine("***************************************");

                Console.WriteLine($"Employee {firstname} {lastname}, has worked for the company for {e1.GetYearsWorked(yearstarted)} years");
                Console.ReadLine();
                Console.Write("Do you want to enter another employee? (y/n) ");
                key = Console.ReadLine().ToUpper();

            } while (key == "Y");

            Console.WriteLine("\n***press any key to exit the program***");
            Console.ReadLine();



        }






    }
}
