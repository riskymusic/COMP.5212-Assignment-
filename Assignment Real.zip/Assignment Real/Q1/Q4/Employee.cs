﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question_4
{
    public class Employee
    {
        public string FirstName { get; set; } //Properties 
        public string LastName { get; set; }
        public int YearStarted { get; set; }

        public Employee(string _firstname, string _lastname)  //Constructor 
        {
            FirstName = _firstname;
            LastName = _lastname;

        }

        public string GetFullName()
        {
            return $"{FirstName} {LastName}";
        }
        public int GetYearsWorked(int yearstarted)
        {
            _ = DateTime.Now.Year;
            return DateTime.Now.Year - yearstarted;
        }
    }
}
