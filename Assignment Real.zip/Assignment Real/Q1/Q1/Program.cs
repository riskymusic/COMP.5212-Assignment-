﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Q1
{
    class program
    {
        static void Main(string[] args)
        {


            Book b1 = new Book();



            Console.WriteLine("*** ENTER NEW BOOK DETAILS BELOW ***\n");
            Console.Write("Please enter your book title:");
            b1.SetTitle(Console.ReadLine());
            Console.Write("Please enter in the author:");
            b1.SetAuthor(Console.ReadLine());
            Console.Write("Please enter in the publisher: ");
            b1.SetPublisher(Console.ReadLine());



            Console.WriteLine("*************************************\n");
            Console.WriteLine("The following new book has been processed: ");
            Console.WriteLine($"Book Title: {b1.GetTitle()}");
            Console.WriteLine($"Author: {b1.GetAuthor()}");
            Console.WriteLine($"Publisher: {b1.GetPublisher()}");
            Console.ReadLine();
        }

    }

    class Book
    {

        private string title;
        private string author;
        private string publisher;



        public string GetTitle()
        {
            return title;
        }

        public void SetTitle(string tle)
        {
            title = tle;
        }

        public string GetAuthor()
        {
            return author;
        }

        public void SetAuthor(string au)
        {
            author = au;
        }
        public string GetPublisher()
        {
            return publisher;
        }

        public void SetPublisher(string pub)
        {
            publisher = pub;
        }




        public Book() { }

        public Book(string tle, string au, string pub)
        {
            title = tle;
            author = au;
            publisher = pub;
        }


    }
}